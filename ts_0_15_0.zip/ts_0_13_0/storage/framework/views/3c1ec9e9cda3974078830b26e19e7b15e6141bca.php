<div class="stuff-header">
    <div>
        <a href="#"
        class="btn btn-success"
        id="insert-new-stuff-button"
        data-user-id="<?php echo e(Auth::id()); ?>">
            <i class="fas fa-plus"></i>
            کالای جدید
        </a>
        <a href="#"
        class="btn btn-info text-light"
        id="insert-new-stuff-file-button"
        data-user-id="<?php echo e(Auth::id()); ?>">
            <i class="fas fa-file-upload "></i>
            ارسال از طریق فایل
        </a>
    </div>

    
</div>
<?php /**PATH E:\MAMP\htdocs\ts_0_13_0\resources\views/stuff/header.blade.php ENDPATH**/ ?>