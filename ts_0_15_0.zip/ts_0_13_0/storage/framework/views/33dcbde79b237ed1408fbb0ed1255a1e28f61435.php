<div class="bg-dark new-header text-light p-4">
        <div class="d-flex">
            <h3>
                <?php echo e(env('APP_NAME')); ?>

            </h3>
            <small title=" <?php echo e($Version[1]); ?> " class="eng text-warning">
               (<?php echo e($Version[0]); ?>)
            </small>
        </div>
</div>
<?php /**PATH E:\MAMP\htdocs\ts_0_13_0\resources\views/layouts/panel/header.blade.php ENDPATH**/ ?>