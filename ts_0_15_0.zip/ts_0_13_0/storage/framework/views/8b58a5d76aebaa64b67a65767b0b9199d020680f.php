<div class="row">
    <div class="col-md-4">
        <div class="mycard outset">
            <div class="number">
                <h1>835</h1>
            </div>
            <div class="desc">
                تعداد کل مخزن ها
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="mycard outset">
            <div class="number">
                <h1>752</h1>
            </div>
            <div class="desc">
                مخزن های نصب شده </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="mycard outset">
            <div class="number">
                <h1>83</h1>
            </div>
            <div class="desc">
                مخزن باقیمانده </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <div class="mycard outset">
            <div class="number">
                <h1>990</h1>
            </div>
            <div class="desc">
کل کیت ها            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="mycard outset">
            <div class="number">
                <h1>753</h1>
            </div>
            <div class="desc">
                کیت های نصب شده </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="mycard outset">
            <div class="number">
                <h1>237</h1>
            </div>
            <div class="desc">
                کیت باقیمانده </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <div class="mycard outset">
            <div class="number">
                <h1>932</h1>
            </div>
            <div class="desc">
                تعداد کل شیر ها
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="mycard outset">
            <div class="number">
                <h1>752</h1>
            </div>
            <div class="desc">
                شیر های نصب شده </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="mycard outset">
            <div class="number">
                <h1>180</h1>
            </div>
            <div class="desc">
                شیر باقیمانده </div>
        </div>
    </div>
</div>
<?php /**PATH E:\MAMP\htdocs\ts_0_13_0\resources\views/contents/dashboard.blade.php ENDPATH**/ ?>