<script src="<?php echo e(asset('js/temp-reciept/modal.js')); ?>"></script>
<?php /**PATH E:\MAMP\htdocs\ts_0_13_0\resources\views/temp-reciept/footer.blade.php ENDPATH**/ ?>