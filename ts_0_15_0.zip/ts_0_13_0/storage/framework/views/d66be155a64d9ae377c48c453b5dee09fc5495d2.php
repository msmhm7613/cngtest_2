<a href="#" class="btn btn-success" id="insert-new-stuff-pack-button" data-user-id="<?php echo e(Auth::id()); ?>">
    <i class="fas fa-plus"></i>
    مجموعه کالای جدید
</a>
<?php /**PATH E:\MAMP\htdocs\ts_0_13_0\resources\views/stuff-pack/header.blade.php ENDPATH**/ ?>