

<?php $__env->startSection( 'content' ); ?>

<?php

use illuminate\Http;

?>

<div class="wizard outset">
        <div class="row">
            <div class="col header">
                <h3>
                    نصب نرم‌افزار
                </h3>
                <p>
                    ما برای نصب نرم‌افزار به اطلاعات زیر نیاز داریم. این نصب فقط یک بار در هنگام شروع کار نرم‌افزار اجرا خواهد شد.
                </p>
                <p class="text-danger">
                    <i class="fas fa-skull-crossbones"></i>
                    توجه: این عملیات کلیه اطلاعات دیتابیس را پاک خواهد کرد و دیتابیس از نو ساخته خواهد شد.
                </p>
                <div id="response">

                </div>
            </div>
        </div>
        <div class="row d-flex justify-content-center align-items-center">
            <!-- <form action="setup" method="post" class="form"> -->
            <?php echo e(Form::open(['url'=>'setup'])); ?>

                <div class="row">
                    <div class="col">
                        <fieldset class="eng">
                            <legend>Database</legend>
                            <div class="form-group">
                                <input type="text" name="dbname" id="dbname" placeholder="Database Name" class=" inset eng"
                                value="<?php echo e(old('dbname')); ?>"
                                >
                                <?php $__errorArgs = ['dbname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="error">
                                        <?php echo e($message); ?>

                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <input type="text" name="dbusername" id="dbusername" placeholder="Database Username" class=" inset eng"
                                value="<?php echo e(old('dbusername')); ?>">
                                <?php $__errorArgs = ['dbusername'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="error">
                                    <?php echo e($message); ?>

                                </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group" id="dbpass">
                                <input type="password" name="dbpassword" id="dbpassword" placeholder="Database Password" class=" inset eng eye"
                                value="<?php echo e(old('dbpassword')?old('dbpassword'):''); ?>"
                                >
                                <i class="fas fa-eye" id="eye" ></i>
                                <?php $__errorArgs = ['dbpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="error">
                                        <?php echo e($message); ?>

                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <input type="text" name="dbport" id="db-port" placeholder="Database Port" class=" inset eng"
                                value="<?php echo e(old('dbport')?old('dbport'):'8889'); ?>"
                                >
                                <?php $__errorArgs = ['dbport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="error">
                                        <?php echo e($message); ?>

                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="submit" value="Next" class="form-control submit outset" onclick="wait()">
                    </div>
                </div>
            </form>
            
        </div>
</div>

<script>
    const eye = document.getElementById('eye')
    const dbpass = document.querySelector('#dbpass #dbpassword')
    eye.addEventListener('click',toggle)
    function toggle(e){
        if ( eye.classList.contains('fa-eye'))
        {
            eye.classList.toggle('fa-eye-slash')
            if ( dbpass.type === 'password' )
                dbpass.type = 'text'
            else
                dbpass.type = 'password'
        }

    }

    function wait(){
        $('#response').html(
            '<div class="spinner-border text-success"></div><p class-"text-success" id="response-text"></p>'
        );

        $('#response-text').text('در حال ساختن دیتابیس...');
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'layouts.head' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MAMP\htdocs\ts_0_13_0\resources\views/install.blade.php ENDPATH**/ ?>