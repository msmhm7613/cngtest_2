<form action="insertTempstore" method="post" id="insert-tempstore-form">
    <div class="form-group">
        <label for="name" class="form-label">
            <span>نام کارگاه:</span>
            <input type="text" name="name" id="name" class="form-input inset">
        </label>
    </div>
    <div class="form-group">
        <label for="manager" class="form-label">
            <span>نام مدیر:</span>
            <input type="text" name="manager" id="manager" class="form-input inset">
        </label>
    </div>
    <div class="form-group">
        <label for="code" class="form-label">
            <span>کد کارگاه:</span>
            <input type="text" name="code" id="code" required autofocus autocomplete="off" class="form-input inset">
        </label>
    </div>
    <div class="form-group">
        <label for="code" class="form-label">
            <span>کد کارگاه:</span>
            <input type="text" name="code" id="code" class="form-input inset">
        </label>
    </div>
    <div class="form-group">
        <label for="phone" class="form-label">
            <span>تلفن کارگاه:</span>
            <input type="text" name="phone" id="phone" class="form-input inset">
        </label>
    </div>
    <div class="form-group">
        <label for="mobile" class="form-label">
            <span>موبایل کارگاه:</span>
            <input type="text" name="mobile" id="mobile" class="form-input inset">
        </label>
    </div>
    <div class="form-group">
        <label for="address" class="form-label">
            <span>آدرس کارگاه:</span>
            <input type="text" name="address" id="address" class="form-input inset">
        </label>
    </div>
    <div class="form-group">
        <label for="description" class="form-label">
            <span>توضیحات</span>
            <input type="text" name="description" id="description" class="form-input inset">
        </label>
    </div>
</form>
