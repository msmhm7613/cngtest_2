<div class="bg-dark new-header text-light p-4">
        <div class="d-flex">
            <h3>
                {{ env('APP_NAME') }}
            </h3>
            <small title=" {{ $Version[1] }} " class="eng text-warning">
               ({{  $Version[0]  }})
            </small>
        </div>
</div>
