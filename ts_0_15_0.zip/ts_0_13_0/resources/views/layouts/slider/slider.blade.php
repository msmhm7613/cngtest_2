{{-- <div id="slider-wrapper">
    <ul id="slider-items">
        <li class="slider-item d-block">
            <img src="{{ asset('storage/images/slides/01.jpg')}}" alt="slider-item" class="slider-item-image">
            <div class="slider-item-caption d-flex justify-content-center align-items-center">
                <h5 class="slider-item-title">

                </h5>
                <p class="slider-item-desc"></p>
                <a href="" class="slider-item-link"></a>
            </div>
        </li>
        <li class="slider-item " style="background: url('{{ asset('storage/images/slides/02.jpg')}}');">

            <div class="slider-item-caption d-flex justify-content-center align-items-center">
                <h5 class="slider-item-title d-inline-block">
                    تـیتر شــماره یــک
                </h5>
                <p class="slider-item-desc"></p>
                <a href="" class="slider-item-link"></a>
            </div>
        </li>
        <li class="slider-item ">
            <img src="{{ asset('storage/images/slides/03.jpg')}}" alt="slider-item" class="slider-item-image">
            <div class="slider-item-caption d-flex justify-content-center align-items-center">
                <h5 class="slider-item-title">

                </h5>
                <p class="slider-item-desc"></p>
                <a href="" class="slider-item-link"></a>
            </div>
        </li>
    </ul>
</div>
 --}}

 <div class="lazy slider " data-size="50vw">
    <div><img src=" {{ asset('storage/images/slides/01.jpg') }}"></div>
    <div><img src=" {{ asset('storage/images/slides/02.jpg') }}"></div>
    <div><img src=" {{ asset('storage/images/slides/03.jpg') }}"></div>
  </div>

  <script src="{{ asset('js/header-slider/kia-slider') }}"></script>

