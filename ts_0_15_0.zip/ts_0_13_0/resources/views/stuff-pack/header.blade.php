<a href="#" class="btn btn-success" id="insert-new-stuff-pack-button" data-user-id="{{ Auth::id() }}">
    <i class="fas fa-plus"></i>
    مجموعه کالای جدید
</a>
