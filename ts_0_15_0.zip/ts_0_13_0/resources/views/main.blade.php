@yield('head')

@yield('body')

@yield('footer')
