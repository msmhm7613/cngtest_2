<a href="#" class="btn btn-success" id="insert-new-store-btn">
    <i class="fas fa-plus">

    </i>
    انبار جدید
</a>


