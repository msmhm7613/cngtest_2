<script src="{{ asset('js/temp-reciept/modal.js') }}"></script>
