/* $('body').on('mouseenter', 'table#stuffs-table tr',function (e) {
    $(e.currentTarget).find('div.btns').first().removeClass('hidden').fadeIn(300);
})

$('body').on('mouseleave','table#stuffs-table tr', function (e) {
    $(e.currentTarget).find('div.btns').addClass('hidden').fadeOut(300);
})
 */
