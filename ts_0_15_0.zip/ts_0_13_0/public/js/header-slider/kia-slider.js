
    $('.lazy').slick({
        autoplay: true,
        dots: true,
        arrows: false,
        autoplaySpeed: 1000,

    });

