<?php

namespace App\Http\Controllers\app\Http\Controllers\temp-reciept;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TempRecieptController2 extends Controller
{
    //
}
