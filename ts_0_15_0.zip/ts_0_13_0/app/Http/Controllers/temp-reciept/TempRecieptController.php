<?php

namespace App\Http\Controllers;

use App\Models\TempReciept;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use PDOException;

class TempRecieptController extends Controller
{
    
}
