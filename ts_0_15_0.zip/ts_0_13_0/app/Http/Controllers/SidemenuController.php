<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SidemenuController extends Controller
{
    
}
